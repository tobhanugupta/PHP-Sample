<?php
/**
 * Travel Logic - booking confirmation template
 */

?>

<section>
	 <div class="container-fluid">
		 <div class="span10">
			 <div class="row-fluid">
				<div class="span12">
					<div class="span8">
						 <h2>
							 Reservation Confirmed!
						 </h2>
						 <!-- p>Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.</p -->
						 <?php tlogic_load_template( 'ticket/book-details.php' ); ?>
					</div>
				 </div>
			 </div>
		 </div>
	 </div>

 </section>