<?php 

echo 'test';
?>