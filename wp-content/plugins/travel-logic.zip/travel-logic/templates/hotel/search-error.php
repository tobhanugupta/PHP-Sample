<?php
/**
 * Travel Logic - hotel search errors template
 */

/* @var string $message the error message */
?>
<span class="help-block span12"><?php echo $message; ?></span>